# SoundTool

SoundTool is a reusable, event-driven audio graph for games. The repository root is the installable `@soundtool/engine` package and contains:

- `packages/sound-engine`: a framework-independent TypeScript runtime.
- `apps/sound-tool`: a visual browser editor for building sound graphs.

## Development

```sh
bun install
bun test
bun run typecheck
bun run dev
```

Open the local address printed by the development command. The editor starts with a small tile-pickup graph. Add local audio with the music-note button, choose an event in the toolbar, and press **Preview**. Add and drag nodes, connect an output dot to an input dot, and edit precise values in the node inspector. Use **Validate** before exporting the graph JSON. Undo and redo are available in the toolbar and through Ctrl+Z/Ctrl+Y.

The editor saves versioned JSON. Games only install the engine package and provide an audio backend plus an optional asset resolver.

## Install from a tagged GitHub release

```sh
bun add @soundtool/engine@github:Pumzow/sound-tool#v0.1.0
```

The compiled engine is committed with each release because Bun does not run untrusted dependency lifecycle scripts by default. Pinning an exact tag keeps game builds reproducible.

## Runtime example

```ts
import { SoundEngine, WebAudioBackend } from "@soundtool/engine";

const engine = new SoundEngine(graph, {
  backend: new WebAudioBackend(),
  resolveSource: (source) => `/sounds/${source}`,
});

await engine.preload();
await engine.emit("tile:combined");
```

## Connecting a game's event manager

The generic bridge keeps game-specific event types out of the sound engine:

```ts
import { bindSoundEvents } from "@soundtool/engine";

const disconnectSounds = bindSoundEvents<EventPayloads, EventTypes>(
  engine,
  Object.values(EventTypes),
  (event, listener) => eventsManager.on(event, listener),
);

// During game shutdown:
disconnectSounds();
engine.destroy();
```

Event-node names in the exported graph should match the game's event string values, such as `puzzle:tile-picked-up`.

## Included in the first milestone

- Event, play, stop-group, volume, pitch-range, bus-volume, delay, probability, and random-branch nodes.
- Versioned JSON import/export with reference and cycle validation.
- A framework-independent runtime with an injectable backend for testing or non-browser platforms.
- A Web Audio backend with preload caching, buses, groups, loops, pitch, and volume.
- A visual editor with draggable nodes, connections, local-file audio preview, undo/redo, a sound library, and a JSON inspector.

The editor and engine are deliberately separate: games ship only `@soundtool/engine`, while the heavier editing interface stays in this repository. Reusable subgraphs, graph-level variables, and packaging the engine as a tagged dependency are good next milestones.
