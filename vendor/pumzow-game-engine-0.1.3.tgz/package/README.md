# GameEngine

Reusable TypeScript runtime systems shared by Pumzow games.

## Included systems

- Typed event manager
- Pausable game timer
- Configurable browser sound manager
- Configurable haptic controller with second-based durations
- Generic scene manager with transition hooks
- Shared time utilities

The package has no dependency on a particular game or renderer. Games provide
their own event map, audio channels, scene registry, UI shell, and transition
effects.

## Commands

```sh
bun install
bun test
bun run typecheck
bun run build
```
