# drygon-huzzle-rules

Shared, versioned Huzzle rules used by the Huzzle client and the DRYGON server.

## Usage

```ts
import {
  huzzle,
} from "drygon-huzzle-rules";

const points = huzzle.utils.pointsForCompletion(3, 6, "card");
const sequence = huzzle.config.gridSizeSequence;
```

The package contains no browser, server, database, or rendering code. Keep every rule that affects server validation in this package so the game and server calculate points from the same source.

## Releasing

1. Update the rules and tests.
2. Run `release-huzzle-rules.bat`.
3. Choose a patch, minor, or major package-version increment.
4. Confirm whether rule behavior changed so `HuzzleRulesVersion` is incremented when required.

The release script validates and builds the package, commits the release, creates a matching `vX.Y.Z` tag, and pushes the commit and tag to GitHub. Huzzle and Server can then run `bun run rules:update` to install the newest tagged release.
