# drygon-huzzle-rules

Shared, versioned Huzzle rules used by the Huzzle client and the DRYGON server.

## Usage

```ts
import {
  huzzle,
} from "drygon-huzzle-rules";

const points = huzzle.utils.pointsForCompletion(3, 6, "card");
const sequence = huzzle.config.gridSizeSequence;
```

The package contains no browser, server, database, or rendering code. Keep every rule that affects server validation in this package so the game and server calculate points from the same source.

## Releasing

1. Update the rules and tests.
2. Increment `HuzzleRulesVersion` when rule behavior changes.
3. Run `bun run check` and `bun run build`.
4. Increment the package version with `npm version patch`, `minor`, or `major`.
5. Publish with `npm publish --access public`.
6. Install the exact new version in Huzzle and Server.
