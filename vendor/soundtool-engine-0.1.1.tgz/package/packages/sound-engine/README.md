# @soundtool/engine

A small TypeScript runtime that executes versioned sound graphs. It has no UI dependency and communicates with audio through the `AudioBackend` interface.

