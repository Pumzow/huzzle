# SoundTool

SoundTool is a reusable, event-driven audio graph for games. The repository root is the installable `@soundtool/engine` package and contains:

- `packages/sound-engine`: a framework-independent TypeScript runtime.
- `apps/sound-tool`: a visual browser editor for building sound graphs.

## Development

```sh
bun install
bun test
bun run typecheck
bun run dev
```

Open the local address printed by the development command. The editor starts with a small tile-pickup graph. Add local audio with the music-note button, choose an event in the toolbar, and press **Preview**. Right-click empty canvas space to create nodes from the grouped menu; the menu scrolls independently from canvas zoom. Hold Space and left-drag to pan, left-drag empty space to box-select nodes, and Ctrl-click nodes to toggle a Windows-style multi-selection. Use the mouse wheel to zoom around the pointer. Drag any selected node to move the whole selection, or hold Ctrl while dragging to snap the group to the grid. Use Ctrl+C, Ctrl+X, and Ctrl+V to copy, cut, and paste selected nodes with their internal connections. Press Ctrl+F to find and focus an existing node. Drag from an output port onto a compatible input port to connect nodes; Shift-drag from a selected node to connect every compatible selected source at once. Dropping a new path on empty canvas opens a filtered menu that creates and connects a compatible node. Either invisible connection endpoint can be grabbed directly and reattached without selecting the path first. Dropping a detached end on empty canvas deletes the connection; Shift-dropping it there opens the same create-and-attach menu. Configure nodes directly through their inline fields or through the full inspector, double-click a node title to rename it, and use the header button to minimize or expand each node. Shift-click that button on a selected node to minimize or expand the full selection together. Event nodes are output-only sources, while Play sound and Log nodes are input-only terminals. Execution cables use the selected theme color and every data cable uses the purple Payload color. Use the small circular button in the lower-right corner to choose a preset or custom full-interface theme; the choice is remembered locally. Drag either vertical divider to resize or fully hide its panel, or double-click the divider to hide or reopen it. Panel widths are remembered locally. Press Delete to remove the selected nodes or connection. Use **Validate** before saving the graph. Undo and redo are available in the toolbar and through Ctrl+Z/Ctrl+Y.

## Graph modules

`Main` is the permanent root graph and cannot be closed or deleted. Create reusable modules from the compact Modules section in the left panel. Left-side module entries only open missing tabs; graph switching happens exclusively through the top tab bar. Closing a tab only hides it, while right-clicking a module in the list exposes the destructive delete action. Main and each module save their own canvas position and zoom in the graph file; use Save after moving the view to retain it when reopening the graph.

Inside a module, create **Module input** and **Module output** nodes to define its public interface. Choose Execution or Payload for each port. Their vertical canvas order becomes the port order on the reusable custom node. Return to Main or another module, open the **Modules** group in the creation menu, and add the module as a custom node. Execution and payload values both pass through nested reusable modules.

## Payloads, debugging, and variables

Every non-execution value travels through a universal Payload port. A payload may contain text, a number, a boolean, an object, or any other runtime value. Values enter the graph through events, Execution debug payloads, variables, and reusable-module ports. **Member** reads a dot-separated path such as `player.profile.name` and returns that value as another payload. Math, Compare, and Branch interpret their connected payloads when they run; conversion cables are no longer required.

Use an **Execution** node to test a graph without a game event: enter JSON or plain text in its Payload field and press **Execute**. Connect its execution output to the flow and its Payload output to Member or another data input. Fields that can also be connected use one combined field-and-socket control instead of showing the same value twice. A **Log** node prints its connected Message payload to the browser or game console; while connected, the same visible Message field is disabled because the incoming payload takes precedence. If no payload is connected, Log prints the message entered on the node.

Create variables from the compact **Variables** section in the left panel. Each declaration owns its name and default payload and displays its current usage count. Use the **G** and **S** shortcuts to create Get or Set nodes, drag a variable onto the canvas to choose either node at the drop position, or right-click it to edit its name and default payload or delete it. Renaming updates every related node; deleting a used variable asks before removing its Get/Set nodes and connections.

Set Variable accepts either a connected Value payload or a value entered directly on the node. A connected payload takes precedence and temporarily disables the direct-value field.

Graph variables are available in Main and every reusable module. Variables created with **This module** scope are private to that module, and every custom-node instance receives independent runtime storage. Values remain available between emitted events until the graph is replaced or the engine variables are explicitly cleared. Older graphs containing implicitly named Get/Set nodes are upgraded to declarations when opened.

Chrome and Edge can open and save the original JSON file directly. Other browsers fall back to file upload and download.

## AI graph assistant

The editor can generate a proposed graph patch from a natural-language prompt. Every response is applied to a cloned graph first, passed through SoundTool's normal graph validator, and shown for review. Nothing changes in the active graph until **Apply graph changes** is pressed.
The assistant always shows the latest model text, including incomplete JSON or a patch that fails validation. The output stays visible when the dialog is reopened, and can be copied for debugging. It is kept in the current page only.
For explicit multi-node requests, the preview checks the requested node count. If a model repeats an incomplete list after producing the requested nodes, SoundTool can recover a reviewable preview for a simple create request; it can also honor an explicit clear-all and connect-to-new-event instruction. The warning in the assistant distinguishes this recovery from a complete model response.

Ollama runs directly from the browser and defaults to `http://localhost:11434` with `llama3.2:3b`. The user must run Ollama locally and allow the deployed SoundTool origin. Hosted providers use the Pages Function at `/api/ai/generate`, so credentials never enter the browser or graph file.

Configure hosted providers in Cloudflare Pages settings:

- Cloudflare Workers AI: add a Workers AI binding named `AI`, then set `AI_ALLOWED_PROVIDERS=cloudflare` and `AI_MODEL` to an available model.
- OpenAI: add the encrypted secret `OPENAI_API_KEY`, then set `AI_ALLOWED_PROVIDERS=openai` and `AI_MODEL`.
- OpenAI-compatible service: set `COMPATIBLE_AI_BASE_URL`, optionally add the encrypted secret `COMPATIBLE_AI_API_KEY`, and set `AI_ALLOWED_PROVIDERS=compatible` plus `AI_MODEL`.
- Multiple hosted providers: use a comma-separated value such as `AI_ALLOWED_PROVIDERS=cloudflare,openai`. Optionally constrain selectable models with `AI_ALLOWED_MODELS`.

Provider and model choices are remembered locally, but API keys are server-side secrets and are never saved in local storage. The endpoint rejects cross-origin requests and oversized prompts; a public deployment should additionally use Cloudflare rate limiting, Turnstile, Access, or another abuse-control layer before enabling a paid provider.

## Game projects

Use **Open project** to edit a game's graph and preview its real audio files in place. The game root needs a `soundtool.project.json` manifest:

```json
{
  "schemaVersion": 1,
  "name": "My Game",
  "graph": "app/config/soundGraph.json",
  "assets": "public",
  "events": {
    "source": "app/types/eventTypes.ts",
    "format": "typescript-string-enum"
  }
}
```

The optional event source populates the Event node dropdown from a TypeScript string enum. Project mode reports missing audio files, sounds that are not used by Play nodes, and graph events missing from the event source. Before replacing the project graph, SoundTool writes an adjacent `*.soundtool-backup.json` file which can be restored from the toolbar. Add that pattern to the game's `.gitignore`.

The editor saves versioned JSON. Games only install the engine package and provide an audio backend plus an optional asset resolver.

## Install from a tagged GitHub release

```sh
bun add @soundtool/engine@github:Pumzow/sound-tool#v0.1.1
```

The compiled engine is committed with each release because Bun does not run untrusted dependency lifecycle scripts by default. Pinning an exact tag keeps game builds reproducible.

## Runtime example

```ts
import { SoundEngine, WebAudioBackend } from "@soundtool/engine";

const engine = new SoundEngine(graph, {
  backend: new WebAudioBackend(),
  resolveSource: (source) => `/sounds/${source}`,
});

await engine.preload();
await engine.emit("tile:combined");
```

Play Sound owns the sound's initial pitch and volume, which can be overridden by connected values. A **Curve** node provides a reusable duration and cubic Bézier curve. Connect it to Play Sound, Stop Sound, or Stop Group through their Fade input, or to Update Sound Pitch and Update Sound Volume through their Transition input. Stop Sound and the update nodes also retain local duration and curve settings when no Curve is connected; Stop Group stops immediately. To transition between sounds, combine Stop Sound and Play Sound with separate Curves. Old saved Crossfade, Fade In, and Fade Out nodes are intentionally unsupported and must be replaced manually.

Loop-region nodes define precise start and end times for downstream looping Play nodes. The Web Audio backend verifies the region against the decoded sound duration so invalid music loops fail clearly during preview instead of producing unpredictable playback.

## Connecting a game's event manager

The generic bridge keeps game-specific event types out of the sound engine:

```ts
import { bindSoundEvents } from "@soundtool/engine";

const disconnectSounds = bindSoundEvents<EventPayloads, EventTypes>(
  engine,
  Object.values(EventTypes),
  (event, listener) => eventsManager.on(event, listener),
);

// During game shutdown:
disconnectSounds();
engine.destroy();
```

Event-node names in the exported graph should match the game's event string values, such as `puzzle:tile-picked-up`.

## Release

Run `release-soundtool.bat`. The guided command asks for a patch, minor, or major bump; updates workspace versions; runs tests, type-checking, and builds; shows every file that will be committed; and asks separately before pushing the release commit and tag.

## Included features

- Event, Play Sound, Stop Sound, stop-group, Update Sound Volume, Update Sound Pitch, bus-volume, delay, probability, and random-branch nodes.
- Curve inputs on Play Sound, Stop Sound, and Stop Group for smooth music and ambience transitions.
- Loop-region nodes for seamless music intros and repeatable sections.
- Universal payload values, Member lookup, variables, comparisons, math, conditional branches, and debug logging.
- Versioned JSON import/export with reference, module-interface, and cycle validation.
- A framework-independent runtime with an injectable backend for testing or non-browser platforms.
- A Web Audio backend with preload caching, buses, groups, loops, pitch, and volume.
- A visual editor with a pannable and zoomable canvas, reusable graph modules, grouped context-menu creation, node search, execution/payload ports, draggable nodes, editable connections, local/project audio preview, undo/redo, direct file saving, project diagnostics, safe backups, a sound library, and form-based node editing.

The editor and engine are deliberately separate: games ship only `@soundtool/engine`, while the heavier editing interface stays in this repository.
